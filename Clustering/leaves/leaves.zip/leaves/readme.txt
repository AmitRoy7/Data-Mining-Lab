
Original data downloaded from:
https://archive.ics.uci.edu/ml/datasets/One-hundred+plant+species+leaves+data+set

leaves_original.txt: Original shape data with float values
leaves.txt: Scaled to integer values
leaves.ts: leaves.txt converted to TS format
leaves.pa: Class label partitions of data

leaves5p1-5: Dataset divided into 5 parts in increasing overlap between classes.

